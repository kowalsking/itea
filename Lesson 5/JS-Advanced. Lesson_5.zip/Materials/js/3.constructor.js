// Функция-конструктор для создания объекта Human.

// function Human(name, surname) {
//     this.name = name;
//     this.surname = surname;
// }

// // Создание 2 экземпляров класса Human
// var firstHuman = new Human("Ivan", "Ivanov");
// var secondHuman = new Human("Petr", "Petrov");
//
//     console.log( firstHuman, secondHuman )


// Функция-конструктор для создания объекта Human.
// function Human(name, surname) {
//     this.name = name;
//     this.surname = surname;
//     this.myProp = "asdasd";
//
//     this.showName = function () {
//       console.log("имя человека: " + this.name + " " + this.surname );
//     }
// }

// // Создание 2 экземпляров класса Human
//
// var firstHuman = new Human("Ivan", "Ivanov");
// var secondHuman = new Human("Petr", "Petrov");
//
// firstHuman.showName();
// secondHuman.showName();
