
function ShowMenu(){
var Somemenu = document.querySelectorAll('.list_block');
    Somemenu.forEach(function(element){
        element.addEventListener("mouseenter", function(event){
            let SecondMenu = event.target.querySelector('.first_content_list');
            SecondMenu.classList.add('open');
        });
        element.addEventListener('mouseleave', function(event){
            let SecondMenu = event.target.querySelector('.first_content_list');
            SecondMenu.classList.remove('open');
        });
    });
}

function Slider(){
    let Img = document.getElementById('pict');
    let Pictures = ['ebay111', 'ebay222', 'ebay333', 'slider_1', 'ebay222', 'ebay333'];
    let a = 0;
    setInterval(function(){
        // console.log(Pictures[a], Pictures.length, a);
        Img.setAttribute('src', `../images/${Pictures[a]}.jpg`);
        if(a === Pictures.length - 1){
            a = 0;
        } else {
            a++;
        }
    }, 3000);
}

function ShowTowns( regions ) {
    let LocationBlock = document.querySelectorAll('.name_location');
    let SomeLocation = document.querySelector('.show_location');
    let SomeForm = document.querySelector('.header_location');


    SomeForm.addEventListener('click', function(open){
        let SomeLocation = document.querySelector('.show_location');
            if (!SomeLocation.classList.contains('location')) {
                SomeLocation.classList.add('location');
            }else {
                SomeLocation.classList.remove('location');
            }
        });

    regions.map( item => {
        let SomeLocation = document.querySelector('.show_location');
        let x = document.createElement('a');
            x.setAttribute( 'href', '#');
            x.classList.add('name_location');
            x.innerText = item.name;
            SomeLocation.appendChild(x);
        });
    }


document.addEventListener('DOMContentLoaded', function(){
    let config = {
        open: false,
        regions: [
            { id: 1, name: "Киев"},
            { id: 2, name: "Харьков"},
            { id: 3, name: "Винница"},
            { id: 4, name: "Львов"},
            { id: 5, name: "Хмельницкий"},
            { id: 6, name: "Черкассы"},
            { id: 7, name: "Одесса"},
            { id: 8, name: "Николаев"},
            { id: 9, name: "Чернигов"},
            { id: 10, name: "Житомир"}
        ]
    };

    ShowMenu();
    Slider();
    ShowTowns( config.regions );
});


/*
    var Regions = [
    {
        id: 1,
        name: "Киев"
    },
    {
        id: 2,
        name: "Харьков"
    },
    {
        id: 3,
        name: "Винница"
    },
    {
        id: 4,
        name: "Львов"
    },
    {
        id: 5,
        name: "Хмельницкий"
    },
    {
        id: 6,
        name: "Черкассы"
    },
    {
        id: 7,
        name: "Одесса"
    },
    {
        id: 8,
        name: "Николаев"
    }
    {
        id: 9,
        name: "Чернигов"
    },
    {
        id: 10,
        name: "Житомир"
    }
    ]

*/
