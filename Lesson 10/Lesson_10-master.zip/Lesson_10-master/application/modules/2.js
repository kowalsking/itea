let myObj = {
  name: 'Frodo',
  age: '39'
};

export default myObj;
