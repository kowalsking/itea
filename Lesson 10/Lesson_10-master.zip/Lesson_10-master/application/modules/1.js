import Obj from './2';

let str = "MyExposrtedString";
let st2 = "123123";
let st3 = {};
console.log('module2:', Obj)

export default st3;
