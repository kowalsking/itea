const mArray = ['1','2','3'];
const mObj = {
  data: ['...']
};

class User {
  constructor(name)  {
    this.name = name;
  }
}

export { mArray, mObj, User };
