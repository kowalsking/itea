import test1 from './class1';
import test2 from './class2';



export default { test1, test2 };
