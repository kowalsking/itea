class test2{}

export default test2;
